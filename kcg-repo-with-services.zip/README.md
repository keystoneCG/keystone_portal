# Keystone Contracting Group — Site Repo (Minimal but Complete)

Included:
- `index.html` (your updated landing page, unchanged)
- `services.html` (so your "See what we do" links work)
- `css/styles.css` (shared styles)
- `README.md`

Deploy the repo via cPanel -> Git Version Control, then **Deploy HEAD**.
Switch the Portal button to https once SSL is fully active.
